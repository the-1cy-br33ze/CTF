from flask import Flask, request, render_template_string, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/calculator')
def calculator():
    return render_template('calculator.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    energy = request.form.get('energy', '0')
    energy_source = request.form.get('energy_source', 'unknown')
    location = request.form.get('location', 'не указан')
    name = request.form.get('name', 'пользователь')
    
    if 'custom_report' in request.form:
        template = request.form.get('template', '')
        return render_template_string(template)
    
    savings = int(energy) * 0.3  # Примерный расчет экономии
    
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Результаты расчета</title>
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; }}
            .result {{ background-color: #e8f5e9; padding: 20px; border-radius: 5px; }}
        </style>
    </head>
    <body>
        <h1>Результаты расчета для {name}</h1>
        <div class="result">
            <p><strong>Регион:</strong> {location}</p>
            <p><strong>Текущее потребление:</strong> {energy} кВт·ч в месяц</p>
            <p><strong>Основной источник:</strong> {energy_source}</p>
            <p><strong>Потенциальная экономия:</strong> {savings} кВт·ч в месяц при переходе на чистую энергию</p>
        </div>
        <p><a href="/calculator">Вернуться к калькулятору</a></p>
    </body>
    </html>
    """

@app.route('/custom_report', methods=['POST'])
def custom_report():
    template = request.form.get('template', '')
    try:
        return render_template_string(template)
    except:
        return "Ошибка при генерации отчета", 400

if __name__ == '__main__':
 app.run(host='0.0.0.0', port=5000, debug=True)
